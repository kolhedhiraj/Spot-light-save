# spotlight-saver-tutorial
Code used for spotlight saver electron app tutorial 
